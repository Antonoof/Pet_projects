Установите зависимости и запустите приложение:

pip install -r requirements.txt
uvicorn app.main:app --reload

Приложение доступно по адресу http://127.0.0.1:8000/