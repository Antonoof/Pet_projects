import numpy as np
import cv2
import tensorflow as tf
from tensorflow.keras.models import load_model

# Загрузка обученной модели
model = load_model('model.h5')

# Функция для предсказания
def predict_digit(image):
    image = cv2.resize(image, (28, 28))
    image = image.reshape(1, 28, 28, 1).astype('float32') / 255
    prediction = model.predict(image)
    return np.argmax(prediction)

# Функция для рисования
def draw_digit(event, x, y, flags, param):
    global drawing, img
    if event == cv2.EVENT_LBUTTONDOWN:
        drawing = True
        img = np.zeros((200, 200, 1), dtype=np.uint8)
    elif event == cv2.EVENT_MOUSEMOVE:
        if drawing:
            cv2.circle(img, (x, y), 10, 255, -1)
    elif event == cv2.EVENT_LBUTTONUP:
        drawing = False
        cv2.circle(img, (x, y), 10, 255, -1)
        digit = predict_digit(img)
        cv2.putText(img, str(digit), (10, 30), cv2.FONT_HERSHEY_SIMPLEX, 1, 255, 2)

# Инициализация переменных
drawing = False
img = np.zeros((200, 200, 1), dtype=np.uint8)

# Создание окна для рисования
cv2.namedWindow('Draw Digit')
cv2.setMouseCallback('Draw Digit', draw_digit)

while True:
    cv2.imshow('Draw Digit', img)
    if cv2.waitKey(1) & 0xFF == 27:  # Нажмите Esc для выхода
        break

cv2.destroyAllWindows()
