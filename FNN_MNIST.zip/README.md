1. Установите библиотеки
pip install tensorflow opencv-python
2. Запустите обучение, можно изменить epochs=2 и batch_szie
python learn_model.py
3. Запустите и опробуйте модель с предсказанием
python main.py

Внимание!!!
Окно закрыватся на ESC.