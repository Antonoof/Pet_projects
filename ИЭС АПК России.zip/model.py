import random
import json
import redis
import time
import math
import matplotlib.pyplot as plt

# Подключение к Redis
r = redis.Redis(host='localhost', port=6379, db=0)

# Классы для элеватора, поезда и корабля
class Elevator:
    def __init__(self, name, location, storage, quantity):
        self.name = name
        self.location = location
        self.storage = storage
        self.quantity = quantity

    def update_storage(self, amount):
        self.storage -= amount
        if self.storage < 0:
            self.storage = 0

class Transport:
    def __init__(self, from_port, to_port, volume, cost, time, current_location, destination, product):
        self.from_port = from_port
        self.to_port = to_port
        self.volume = volume
        self.cost = cost
        self.time = time
        self.current_location = current_location
        self.destination = destination
        self.product = product

    def move(self):
        current_lat, current_lng = map(float, self.current_location.split(','))
        dest_lat, dest_lng = map(float, self.destination.split(','))
        distance = math.sqrt((dest_lat - current_lat) ** 2 + (dest_lng - current_lng) ** 2)
        speed = distance / self.time  # Переводим время в дни
        if distance > speed:
            new_lat = current_lat + (dest_lat - current_lat) * speed / distance
            new_lng = current_lng + (dest_lng - current_lng) * speed / distance
        else:
            new_lat, new_lng = dest_lat, dest_lng
        self.current_location = f"{new_lat},{new_lng}"

# Пример данных
ports = [
    {"name": "Турция. Порт Измир", "location": "38.4462, 27.1568", "capacity": 22, "current_load": 94, "product": "зерно, растительное масло"},
    {"name": "Турция. Порт Стамбул", "location": "41.0216, 28.9767", "capacity": 492, "current_load": 76, "product": "зерно"},
    {"name": "Египет. Порт Александрия", "location": "31.1947, 29.8801", "capacity": 55, "current_load": 7, "product": "зерно"},
    {"name": "Египет. Порт Дамиетта", "location": "31.4577, 31.7598", "capacity": 30, "current_load": 45, "product": "зерно"},
    {"name": "Египет. Порт Порт-Саид", "location": "31.2596, 32.3014", "capacity": 25, "current_load": 89, "product": "зерно"},
    {"name": "Иран. Порт Бендер-Аббас", "location": "27.1797, 56.2932", "capacity": 47, "current_load": 32, "product": "зерно"},
    {"name": "Иран. Порт Бушир", "location": "28.9930, 50.8318", "capacity": 55, "current_load": 30, "product": "зерно"},
    {"name": "Саудовская Аравия. Порт Джидда", "location": "21.4690, 39.1595", "capacity": 46, "current_load": 83, "product": "зерно, мясо"},
    {"name": "Саудовская Аравия. Порт Даммам", "location": "26.4940, 50.2153", "capacity": 266, "current_load": 29, "product": "зерно, мясо"},
    {"name": "Бангладеш. Порт Читтагонг", "location": "22.3353, 91.8340", "capacity": 50, "current_load": 46, "product": "зерно"},
    {"name": "Бангладеш. Порт Монгла", "location": "22.4833, 89.6333", "capacity": 5, "current_load": 52, "product": "зерно"},
    {"name": "Китай. Порт Шанхай", "location": "31.2304, 121.4737", "capacity": 2401, "current_load": 48, "product": "мясо, рыба, кондитерские изделия, растительное масло"},
    {"name": "Китай. Порт Тяньцзинь", "location": "39.1314, 117.1921", "capacity": 696, "current_load": 29, "product": "мясо, рыба, кондитерские изделия, растительное масло"},
    {"name": "Казахстан. Порт Актау", "location": "43.6442, 51.1714", "capacity": 11, "current_load": 4, "product": "мясо, сахар, кондитерские изделия"},
    {"name": "Казахстан. Порт Атырау", "location": "47.1167, 51.8667", "capacity": 2, "current_load": 8, "product": "мясо, сахар, кондитерские изделия"},
    {"name": "Южная Корея. Порт Пусан", "location": "35.1028, 129.0403", "capacity": 398, "current_load": 73, "product": "рыба"},
    {"name": "Южная Корея. Порт Инчхон", "location": "37.4563, 126.7052", "capacity": 192, "current_load": 18, "product": "рыба"},
    {"name": "Япония. Порт Токио", "location": "35.6895, 139.6917", "capacity": 63, "current_load": 108, "product": "рыба"},
    {"name": "Япония. Порт Йокогама", "location": "35.4437, 139.6381", "capacity": 94, "current_load": 184, "product": "рыба"},
    # поезда
    {"name": "Таджикистан. Душанбе", "location": "38.5600, 68.7800", "capacity": 30, "current_load": 32, "product": "сахар"},
    {"name": "Таджикистан. Худжанд", "location": "40.2833, 69.6333", "capacity": 12, "current_load": 84, "product": "сахар"},
    {"name": "Узбекистан. Термез", "location": "37.2333, 67.2667", "capacity": 23, "current_load": 64, "product": "сахар, кондитерские изделия"},
    {"name": "Узбекистан. Нукус", "location": "42.4667, 59.6000", "capacity": 13, "current_load": 21, "product": "сахар, кондитерские изделия"},
    {"name": "Белоруссия. Минск", "location": "53.9000, 27.5667", "capacity": 100, "current_load": 69, "product": "кондитерские изделия"},
    {"name": "Белоруссия. Брест", "location": "52.0967, 23.6700", "capacity": 31, "current_load": 54, "product": "кондитерские изделия"},
    {"name": "Россия. Новороссийск", "location": "44.7191, 37.7734", "capacity": 130, "current_load": 80, "product": "сахар, кондитерские изделия, зерно"},
    {"name": "Россия. Туапсе", "location": "44.1042, 39.0797", "capacity": 20, "current_load": 12, "product": "сахар, кондитерские изделия, зерно"},
    {"name": "Россия. Таганрог", "location": "47.2220, 38.9165", "capacity": 15, "current_load": 79, "product": "сахар, кондитерские изделия, зерно"},
    {"name": "Россия. Азов", "location": "47.0981, 39.4201", "capacity": 10, "current_load": 64, "product": "сахар, кондитерские изделия, зерно"},
    {"name": "Россия. Ростов-на-Дону", "location": "47.2220, 39.7204", "capacity": 8, "current_load": 53, "product": "сахар, кондитерские изделия, зерно"},
    # корабли
    {"name": "Алжир. Порт Алжир", "location": "36.7529, 3.0420", "capacity": 26, "current_load": 13, "product": "растительное масло"},
    {"name": "Алжир. Порт Оран", "location": "35.7075, -0.6340", "capacity": 19, "current_load": 23, "product": "растительное масло"},
    {"name": "Индия. Порт Мумбаи", "location": "18.9388, 72.8353", "capacity": 152, "current_load": 39, "product": "растительное масло"},
    {"name": "Индия. Порт Ченнаи", "location": "13.0827, 80.2707", "capacity": 19, "current_load": 47, "product": "растительное масло"},
    # можем предложить
    {"name": "Индонезия. Порт Джакарта", "location": "-6.1264, 106.8267", "capacity": 204, "current_load": 82, "product": "зерно, сахар, рыба, кондитерские изделия"},
    {"name": "Индонезия. Порт Сурабая", "location": "-7.2575, 112.7521", "capacity": 82, "current_load": 91, "product": "зерно, сахар, рыба, кондитерские изделия"},
    {"name": "Мексика. Порт Веракрус", "location": "19.1925, -96.1314", "capacity": 26, "current_load": 20, "product": "зерно"},
    {"name": "Мексика. Порт Мансанильо", "location": "15.5500, -102.1667", "capacity": 27, "current_load": 104, "product": "зерно"},
    {"name": "Бразилия. Порт Сантус", "location": "-23.9556, -46.3319", "capacity": 105, "current_load": 30, "product": "зерно"},
    {"name": "Бразилия. Порт Рио-де-Жанейро", "location": "-22.9068, -43.1729", "capacity": 173, "current_load": 62, "product": "зерно"},
    # Россия
    {"name": "Россия. Порт Мурманск", "location": "68.978379, 33.068189", "capacity": 166, "current_load": 25, "product": "рыба, замороженные продукты, мясо"},
    {"name": "Россия. Порт Владивосток", "location": "43.097600, 131.865821", "capacity": 137, "current_load": 20, "product": "рыба, зерно, кондитерские изделия"},
    {"name": "Россия. Порт Санкт-Петербург", "location": "59.911214, 30.250740", "capacity": 108, "current_load": 15, "product": "растительное масло, мясо, кондитерские изделия, сахар"},
    {"name": "Россия. Порт Новороссийск", "location": "44.724392, 37.776287", "capacity": 96, "current_load": 22, "product": "зерно, растительное масло, сахар, мясо"},
    {"name": "Россия. Порт Архангельск", "location": "64.703108, 40.523182", "capacity": 76, "current_load": 39, "product": "рыба, зерно"},
    {"name": "Россия. Порт Петропавловск-Камчатский", "location": "53.005796, 158.657436", "capacity": 72, "current_load": 25, "product": "рыба, растительное масло"},
    {"name": "Россия. Порт Усть-Луга", "location": "59.698491, 28.427963", "capacity": 63, "current_load": 63, "product": "зерно, растительное масло, мясо, рыба"},
    {"name": "Россия. Порт Находка", "location": "42.794101, 132.870739", "capacity": 56, "current_load": 23, "product": "зерно, рыба, сахар"},
    {"name": "Россия. Порт Калининград", "location": "54.699123, 20.476064", "capacity": 45, "current_load": 42, "product": "растительное масло, мясо, рыба"},
    {"name": "Россия. Порт Астрахань", "location": "46.343707, 47.997363", "capacity": 43, "current_load": 30, "product": "рыба, зерно"},
    {"name": "Россия. Порт Сочи", "location": "43.5855, 39.7231", "capacity": 36, "current_load": 19, "product": "зерно, растительное масло, мелкие партии грузов"}
]

elevators = [
    Elevator("Элеватор Краснодар", "45.0355, 38.9753", 12700000, 78),
    Elevator("Элеватор Орловская", "52.9686, 36.0696", 3300000, 27),
    Elevator("Элеватор Астрахань", "46.3478, 48.0335", 1400000, 17),
    Elevator("Элеватор Барнаул", "53.3561, 83.7427", 800000, 31),
    Elevator("Элеватор Воронеж", "51.6607, 39.2005", 4600000, 36),
    Elevator("Элеватор Липецк", "52.6087, 39.5992", 2000000, 27),
    Elevator("Элеватор Саратов", "51.5336, 46.0342", 3400000, 52),
    Elevator("Элеватор Уфа", "54.7351, 55.9583", 3200000, 50),
    Elevator("Элеватор Челябинск", "55.1603, 61.4009", 2700000, 18),
    Elevator("Элеватор Курган", "55.4481, 65.3423", 1400000, 25),
    Elevator("Элеватор Омск", "54.9893, 73.3682", 1800000, 26)
]

transports = []

# Инициализация данных в Redis
for port in ports:
    r.hset(f"port:{port['name']}", mapping=port)

for elevator in elevators:
    r.hset(f"elevator:{elevator.name}", mapping={
        "name": elevator.name,
        "location": elevator.location,
        "storage": elevator.storage,
        "quantity": elevator.quantity
    })

# Ввод целевого дохода
target_revenue = float(input("Введите целевой доход для России (в долларах): "))

# Функция для обновления данных
def update_data():
    global target_revenue
    global total_revenue
    # Обновление данных о портах
    for port in ports:
        port_key = f"port:{port['name']}"
        port_data = r.hgetall(port_key)
        current_load = int(port_data[b'current_load'].decode('utf-8'))
        capacity = int(port_data[b'capacity'].decode('utf-8'))
        new_load = min(current_load + random.randint(0, 10000), capacity)
        r.hset(port_key, 'current_load', new_load)

    # Обновление данных о транспорте
    for transport in transports:
        from_key = f"port:{transport.from_port}"
        to_key = f"port:{transport.to_port}"
        from_data = r.hgetall(from_key)
        to_data = r.hgetall(to_key)
        from_current_load = int(from_data[b'current_load'].decode('utf-8'))
        to_current_load = int(to_data[b'current_load'].decode('utf-8'))
        to_capacity = int(to_data[b'capacity'].decode('utf-8'))

        if from_current_load >= transport.volume and to_current_load + transport.volume <= to_capacity:
            r.hset(from_key, 'current_load', from_current_load - transport.volume)
            r.hset(to_key, 'current_load', to_current_load + transport.volume)

        # Обновление текущего местоположения транспорта
        transport.move()

        # Сохранение обновленного местоположения транспорта в Redis
        r.hset(f"transport:{transport.from_port}_{transport.to_port}", mapping={
            "current_location": transport.current_location
        })

    # Генерация новых транспортов
    generate_transports()

    # Проверка достижения целевого дохода
    current_revenue = calculate_current_revenue()
    total_revenue += current_revenue
    if total_revenue >= target_revenue:
        print(f"Целевой доход достигнут: ${total_revenue}")
    else:
        print(f"Текущий доход: ${total_revenue}, целевой доход: ${target_revenue}")

def generate_transports():
    # Генерация новых транспортов
    for port in ports:
        if "Россия" in port['name']:
            continue
        if random.random() < 0.1:  # 10% вероятность генерации нового транспорта
            from_port = port['name']
            to_port = random.choice([p['name'] for p in ports if "Россия" in p['name'] and p['name'] != from_port])
            volume = random.randint(1000, 10000)
            cost = random.randint(1000, 10000)
            time = random.randint(1, 10)
            current_location = port['location']
            destination = r.hgetall(f"port:{to_port}")[b'location'].decode('utf-8')
            product = port['product']
            transport = Transport(from_port, to_port, volume, cost, time, current_location, destination, product)
            transports.append(transport)
            r.hset(f"transport:{from_port}_{to_port}", mapping={
                "from": from_port,
                "to": to_port,
                "type": "ship" if "Порт" in from_port else "train",
                "volume": volume,
                "cost": cost,
                "time": time,
                "current_location": current_location,
                "destination": destination,
                "product": product
            })

def calculate_current_revenue():
    # Подсчет текущего дохода
    current_revenue = 0
    for transport in transports:
        if transport.to_port.startswith("Россия") and transport.cost > 0:
            current_revenue += transport.cost
    return current_revenue

# Запуск симуляции
total_revenue = 0
for day in range(365):
    update_data()
    time.sleep(1)  # 1 итерация = 1 секунда

    # Уменьшение времени транспорта и удаление, если время истекло
    for transport in transports:
        transport.time -= 1
        if transport.time <= 0:
            transports.remove(transport)
            r.delete(f"transport:{transport.from_port}_{transport.to_port}")

    # Обновление текущего местоположения транспорта
    for transport in transports:
        transport.move()
        r.hset(f"transport:{transport.from_port}_{transport.to_port}", mapping={
            "current_location": transport.current_location
        })

    # Удаление транспорта, если он вернулся в Россию
    for transport in transports:
        if transport.current_location == transport.destination and "Россия" in transport.to_port:
            transports.remove(transport)
            r.delete(f"transport:{transport.from_port}_{transport.to_port}")
            # Увеличение загруженности порта
            port_key = f"port:{transport.to_port}"
            port_data = r.hgetall(port_key)
            current_load = int(port_data[b'current_load'].decode('utf-8'))
            capacity = int(port_data[b'capacity'].decode('utf-8'))
            new_load = min(current_load + transport.volume, capacity)
            r.hset(port_key, 'current_load', new_load)

# Проверка достижения целевого дохода в конце года
if total_revenue >= target_revenue:
    print(f"Целевой доход достигнут: ${total_revenue}")
else:
    print(f"Целевой доход не достигнут: ${total_revenue}")

# Сохранение графиков для анализа
def plot_revenue_over_time(revenue_data):
    plt.figure(figsize=(10, 6))
    plt.plot(revenue_data.keys(), revenue_data.values(), marker='o')
    plt.title('Доход за год')
    plt.xlabel('День')
    plt.ylabel('Доход (в долларах)')
    plt.grid(True)
    plt.savefig('revenue_over_time.png')
    plt.close()

def plot_transport_count_over_time(transport_count_data):
    plt.figure(figsize=(10, 6))
    plt.plot(transport_count_data.keys(), transport_count_data.values(), marker='o')
    plt.title('Количество транспорта за год')
    plt.xlabel('День')
    plt.ylabel('Количество транспорта')
    plt.grid(True)
    plt.savefig('transport_count_over_time.png')
    plt.close()

# Пример данных для графиков
revenue_data = {day: total_revenue for day in range(365)}
transport_count_data = {day: len(transports) for day in range(365)}

# Сохранение графиков
plot_revenue_over_time(revenue_data)
plot_transport_count_over_time(transport_count_data)
