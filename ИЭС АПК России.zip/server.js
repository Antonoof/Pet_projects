const express = require('express');
const redis = require('redis');
const path = require('path');
const app = express();
const port = 3000;

// Create a Redis client
const client = redis.createClient({
    host: process.env.REDIS_HOST,
    port: process.env.REDIS_PORT
});

client.on('error', (err) => {
    console.error('Redis error:', err);
});

client.on('connect', () => {
    console.log('Connected to Redis');
});

// Serve static files from the root directory
app.use(express.static(path.join(__dirname)));

// API endpoint to get port data
app.get('/api/ports', async (req, res) => {
    try {
        const keys = await new Promise((resolve, reject) => {
            client.keys('port:*', (err, keys) => {
                if (err) reject(err);
                resolve(keys);
            });
        });

        const promises = keys.map(async (key) => {
            const name = key.split(':')[1];
            const results = await new Promise((resolve, reject) => {
                client.hgetall(key, (err, results) => {
                    if (err) reject(err);
                    resolve(results);
                });
            });

            return {
                name,
                location: results.location,
                capacity: results.capacity,
                current_load: results.current_load,
                product: results.product
            };
        });

        const data = await Promise.all(promises);
        res.json(data);
    } catch (err) {
        console.error('Error fetching port data:', err);
        res.status(500).send('Internal Server Error');
    }
});

// API endpoint to get elevator data
app.get('/api/elevators', async (req, res) => {
    try {
        const keys = await new Promise((resolve, reject) => {
            client.keys('elevator:*', (err, keys) => {
                if (err) reject(err);
                resolve(keys);
            });
        });

        const promises = keys.map(async (key) => {
            const name = key.split(':')[1];
            const results = await new Promise((resolve, reject) => {
                client.hgetall(key, (err, results) => {
                    if (err) reject(err);
                    resolve(results);
                });
            });

            return {
                name,
                location: results.location,
                storage: results.storage,
                quantity: results.quantity
            };
        });

        const data = await Promise.all(promises);
        res.json(data);
    } catch (err) {
        console.error('Error fetching elevator data:', err);
        res.status(500).send('Internal Server Error');
    }
});

// API endpoint to get transport data
app.get('/api/transports', async (req, res) => {
    try {
        const keys = await new Promise((resolve, reject) => {
            client.keys('transport:*', (err, keys) => {
                if (err) reject(err);
                resolve(keys);
            });
        });

        const promises = keys.map(async (key) => {
            const results = await new Promise((resolve, reject) => {
                client.hgetall(key, (err, results) => {
                    if (err) reject(err);
                    resolve(results);
                });
            });

            return {
                from: results.from,
                to: results.to,
                type: results.type,
                volume: results.volume,
                cost: results.cost,
                time: results.time,
                current_location: results.current_location,
                destination: results.destination,
                product: results.product
            };
        });

        const data = await Promise.all(promises);
        res.json(data);
    } catch (err) {
        console.error('Error fetching transport data:', err);
        res.status(500).send('Internal Server Error');
    }
});

// Serve the HTML file
app.get('/', (req, res) => {
    res.sendFile(path.join(__dirname, 'index.html'));
});

app.listen(port, () => {
    console.log(`Server running at http://localhost:${port}`);
});
