## Как запустить приложение

Linux
```shell
uv pip install .
source ./.venv/bin/activate
streamlit run app.py
```

Windows
```powershell
uv pip install .
.\.venv\Scripts\activate
streamlit run app.py
```
